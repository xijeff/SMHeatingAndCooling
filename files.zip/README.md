# Summit Heating & Cooling — multi-page site

32 pages, flat file structure, no build step. Every link is relative, so it works on Netlify, Vercel, or any static host by dragging the folder in.

## Structure

| Page group | Files | Purpose |
|---|---|---|
| Home | `index.html` | Brand + conversion hub |
| Services hub | `services.html` | Links to all 12 service pages |
| Service pages (12) | `ac-repair.html`, `ac-installation.html`, `furnace-repair.html`, `heating-installation.html`, `heat-pumps.html`, `ductless-mini-splits.html`, `boiler-radiator-service.html`, `ductwork-airflow.html`, `indoor-air-quality.html`, `thermostats-smart-controls.html`, `maintenance-plans.html`, `emergency-hvac.html` | One page per money keyword |
| Areas hub | `service-areas.html` | Links to all 14 town pages |
| Town pages (14) | `hvac-somerville-nj.html`, `hvac-bridgewater-nj.html`, `hvac-raritan-nj.html`, `hvac-hillsborough-nj.html`, `hvac-branchburg-nj.html`, `hvac-manville-nj.html`, `hvac-bound-brook-nj.html`, `hvac-warren-nj.html`, `hvac-watchung-nj.html`, `hvac-green-brook-nj.html`, `hvac-bedminster-nj.html`, `hvac-basking-ridge-nj.html`, `hvac-flemington-nj.html`, `hvac-middlesex-nj.html` | "HVAC + [town]" local rankings |
| Company | `about.html`, `contact.html`, `faq.html` | Trust + conversion |
| Infra | `styles.css`, `main.js`, `sitemap.xml`, `robots.txt` | — |

## Before you launch — replace the placeholders

Search-and-replace across all files (they're consistent):

1. **Domain** — `https://www.summithvacnj.com` appears in canonicals, Open Graph, schema and `sitemap.xml`. Replace with your real domain everywhere.
2. **Phone** — `(908) 555-0123` and `+19085550123`
3. **Email** — `hello@summithvac.com`
4. **Address** — `25 Division Street, Somerville, NJ 08876`
5. **License number** — `NJ HVACR Lic. #00000`
6. **Social links** — the three footer icons are `href="#"`
7. **Reviews** — the six testimonials are placeholders. Swap in real ones once you have them.
8. **`og-image.jpg`** — drop a 1200×630 image in the root. It's referenced but not included.

The "4.9 from 200+ reviews" line on the homepage is also a placeholder. I deliberately did **not** put `aggregateRating` in the schema — Google penalizes self-serving review markup, and fake review counts are an FTC problem. Once you have real Google reviews, link the Google Business Profile instead.

## Wire up the form

The forms currently show a local confirmation and don't send anything (see the `data-lead-form` handler in `main.js`). To make them real, pick one:

**Netlify Forms** — add to each `<form>` tag:
```html
<form data-lead-form name="quote" method="POST" data-netlify="true">
  <input type="hidden" name="form-name" value="quote">
```

**Formspree / Web3Forms** — add an `action`:
```html
<form data-lead-form action="https://formspree.io/f/YOUR_ID" method="POST">
```
`main.js` detects the `action` attribute and lets the real post through automatically.

There are 5 form instances (home, service pages, town pages, about, contact). They all share the same markup.

## Local SEO — what's already done

- Unique title, meta description, canonical, and H1 on all 32 pages
- `HVACBusiness` JSON-LD with NAP, geo coordinates, hours, and `areaServed` on every page
- `Service`, `BreadcrumbList` and `FAQPage` schema where applicable
- Visible breadcrumbs on every interior page
- Internal linking mesh: services ↔ towns ↔ hubs (every town page links to all 12 services; every service page links to all 14 towns)
- Town pages have genuinely distinct copy — housing stock, local HVAC problems, landmarks, zips. Duplicate town pages with only the name swapped are what Google's spam filters target.
- `sitemap.xml` + `robots.txt`
- Mobile: sticky bottom call/quote bar, 48px tap targets, 16px form inputs (stops iOS zoom-on-focus), full-screen nav drawer, single-column reflow at 720px

## What to do after launch (this is where local rankings actually come from)

1. **Google Business Profile** — claim it, category "HVAC contractor", exact same NAP as the footer. This drives the map pack more than the site does.
2. **Reviews** — ask every customer. Volume and recency both matter.
3. **Citations** — Yelp, Angi, BBB, Nextdoor, Apple Maps, Bing Places. Identical NAP.
4. **Submit the sitemap** in Google Search Console.
5. **Add real photos** — two placeholder slots are marked in the layout. Real job photos beat stock badly, and geotagged originals help.
6. **Add towns over time** rather than all at once — build.py makes this a one-line addition.

## Regenerating

The whole site is generated from `build.py` + `data.py` (in the source folder, not deployed). Add a town or service to `data.py`, run `python3 build.py`, and every nav menu, footer, sitemap and cross-link updates itself. That's much better than hand-editing 32 files when you want to add "Bernardsville."
